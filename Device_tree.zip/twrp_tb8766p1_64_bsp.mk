$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base_telephony.mk)

# Inherit from our custom device configurations
$(call inherit-product, device/tcl/tb8766p1_64_bsp/device.mk)

# Inherit TWRP minimal product configurations
$(call inherit-product, vendor/twrp/config/common.mk)

PRODUCT_DEVICE := tb8766p1_64_bsp
PRODUCT_NAME := twrp_tb8766p1_64_bsp
PRODUCT_BRAND := TCL
PRODUCT_MODEL := TCL Tab 10L Gen 2
PRODUCT_MANUFACTURER := tcl
