PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/twrp_tb8766p1_64_bsp.mk

COMMON_LUNCH_CHOICES := \
    twrp_tb8766p1_64_bsp-eng
