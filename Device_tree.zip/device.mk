# Establish the current local workspace path
LOCAL_PATH := device/tcl/tb8766p1_64_bsp

# Invoke standard core telephony and handheld definitions
$(call inherit-product, $(SRC_TARGET_DIR)/product/languages_full.mk)

# Define runtime storage characteristics for MediaTek
PRODUCT_CHARACTERISTICS := tablet

# Target properties to aid TWRP UI rendering and MTP operations
PRODUCT_PROPERTY_OVERRIDES += \
    ro.secure=0 \
    ro.adb.secure=0 \
    ro.allow.mock.locations=1 \
    ro.debuggable=1 \
    persist.sys.usb.config=mtp,adb \
    ro.sys.usb.storage.type=mtp

# Call key layout configs if they were extracted by AIK
# (Uncomment the line below if you copy your ramdisk's key layouts)
# PRODUCT_COPY_FILES += $(LOCAL_PATH)/kl/mtk-kpd.kl:recovery/root/system/usr/keylayout/mtk-kpd.kl
