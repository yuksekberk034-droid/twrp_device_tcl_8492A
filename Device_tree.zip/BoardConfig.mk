DEVICE_PATH := device/tcl/tb8766p1_64_bsp

# Architecture
TARGET_ARCH := arm64
TARGET_ARCH_VARIANT := armv8-a
TARGET_CPU_ABI := arm64-v8a
TARGET_CPU_ABI2 := 
TARGET_USES_64_BIT_BINDER := true

# Platform / MediaTek
TARGET_BOARD_PLATFORM := mt8766
BOARD_HAS_MTK_HARDWARE := true
TARGET_RECOVERY_DEVICE_MODULES := libion

# Kernel Command Line & Settings (Grab these from AIK split_img folder)
BOARD_KERNEL_CMDLINE := bootopt=64S3CBRE,32S3CBRE,32S3CBRE
BOARD_KERNEL_PAGESIZE := 2048

# TWRP Configuration Flags
TW_THEME := portrait_hdpi
RECOVERY_SDCARD_ON_DATA := true
TARGET_RECOVERY_PIXEL_FORMAT := "RGBX_8888"
TW_BRIGHTNESS_PATH := "/sys/class/leds/lcd-backlight/brightness"
TW_MAX_BRIGHTNESS := 255

# Dynamic Partitions configuration
BOARD_SUPER_PARTITION_SIZE := 9126805504
BOARD_SUPER_PARTITION_GROUPS := tcl_dynamic_partitions
BOARD_TCL_DYNAMIC_PARTITIONS_SIZE := 9122611200
BOARD_TCL_DYNAMIC_PARTITIONS_PARTITION_LIST := system vendor product

# TWRP specific features
TW_INCLUDE_CRYPTO := true
TW_INCLUDE_CRYPTO_FBE := true
BOARD_KERNEL_IMAGE_NAME := Image.gz
